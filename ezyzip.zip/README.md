Pre-requiste

Install openebs  --- refer OPENEBS > Readme.md file
https://openebs.io/docs/user-guides/localpv-hostpath![image](https://user-images.githubusercontent.com/114899479/232010036-14cc7798-33bf-4bcd-972c-ce625756cbe3.png)

################## HELM INSTALLATION ##################################

 - wget https://get.helm.sh/helm-v3.8.0-linux-amd64.tar.gz 
 - tar -zxvf helm-v3.8.0-linux-amd64.tar.gz 
 - mv linux-amd64/helm /usr/local/bin/helm

#################### GRAFANA ########################################

helm repo add grafana https://grafana.github.io/helm-charts
helm install appshell-perf-garfana  grafana/grafana

kubectl expose service  appshell-perf-garfana-grafana --type=NodePort --target-port=3000 --name=appshell-perf-garfana-grafana-ext

Kubectl get secret

kubectl get secret --namespace default appshell-perf-garfana-grafana -o jsonpath="{.data.admin-password}" | base64 --decode ; echo


Using this command we will get the grafana login passwd

######################################################################

PROMETHEUS

Git clone https://github.com/bh-ent-tech/grafana-helm.git

In prometheus > values.yaml

205 --- set it to true  && in line 238 uncomment storage class & add the value
920 --- 924 set it to true  && in line 961 uncomment storage class & add the valu
385 -- nodeport


https://openebs.io/docs/user-guides/localpv-hostpath

kubectl apply -f https://openebs.github.io/charts/openebs-operator.yaml

Delete storage class openebs-hostpath
& create a  openebs-hostpath.yaml

apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: openebs-hostpath2
  annotations:
    openebs.io/cas-type: local
    cas.openebs.io/config: |
      - name: StorageType
        value: hostpath
      - name: BasePath
        value: /root/efs-mount-point/
provisioner: openebs.io/local
reclaimPolicy: Retain
volumeBindingMode: WaitForFirstConsumer


Kubectl apply -f openebs-hostpath.yaml

#######################################################################


Cd loki-stack
promtail & loki --- true
Other things are false
edit values.yaml > line 42 -- change grafana to false & prometheus false

Helm install loki . -f values.yaml

In dashboard:

Add datasource >
loki > http://loki:3100 > save& test
